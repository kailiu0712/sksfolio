"""Test package for sksfolio."""
